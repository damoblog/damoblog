using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;

/// <summary>
/// puerts工具配置
/// </summary>
[Puerts.Configure]
public class MyPuertsCfg
{
    /// <summary>
    /// 不生成静态绑定代码，只导出（给ts）
    /// </summary>
    [Puerts.Typing]
    public static IEnumerable<Type> Typings
    {
        get
        {
            return new List<Type>()
                {
                    //由于自动生成的cs代码，KeyValuePair没有析构函数，编译报错，所以只导出不绑定
                    typeof(System.Collections.Generic.KeyValuePair<string, int>),
                };
        }
    }

    /// <summary>
    /// 部分C# System接口绑定与导出（到ts）
    /// </summary>
    [Puerts.Binding]
    public static IEnumerable<Type> CsharpBindings
    {
        get
        {
            return new List<Type>()
                {
                    typeof(System.Array),
                    typeof(System.Object),
                    typeof(System.Type),
                    typeof(System.Delegate),
                    typeof(System.Collections.Generic.ICollection<UnityEngine.Object>),
                    typeof(System.Collections.Generic.IList<UnityEngine.Object>),
                };
        }
    }

    /// <summary>
    /// 部分Unity Engine接口绑定与导出（到ts）
    /// </summary>
    [Puerts.Binding]
    public static IEnumerable<Type> UnityBindings
    {
        get
        {
            return new List<Type>()
                {
                    typeof(UnityEngine.Color),
                    typeof(UnityEngine.Debug),
                    typeof(UnityEngine.Time),
                    typeof(UnityEngine.Rect),
                    typeof(UnityEngine.Vector2),
                    typeof(UnityEngine.Vector3),
                    typeof(UnityEngine.Quaternion),
                    typeof(UnityEngine.Application),
                    typeof(UnityEngine.RuntimePlatform),
                    typeof(UnityEngine.Object),
                    typeof(UnityEngine.GameObject),
                    typeof(UnityEngine.Transform),
                    typeof(UnityEngine.Behaviour),
                    typeof(UnityEngine.MonoBehaviour),
                    typeof(UnityEngine.Component),
                    typeof(UnityEngine.AudioSource),
                    typeof(UnityEngine.TextAsset),
                    typeof(UnityEngine.PlayerPrefs),
                    typeof(UnityEngine.Camera),
                    typeof(UnityEngine.CapsuleCollider),
                    typeof(UnityEngine.Collider),
                    typeof(UnityEngine.LayerMask),
                    typeof(UnityEngine.Renderer),
                    typeof(UnityEngine.SpriteRenderer),
                    typeof(UnityEngine.SceneManagement.LoadSceneMode),
                    typeof(UnityEngine.RectTransform),
                    typeof(UnityEngine.Screen),
                };
        }
    }

    [Puerts.Binding]
    public static IEnumerable<Type> UnityNameSpaceBindings
    {
        get
        {
            string[] namespaces = {
                    "UnityEngine.UI",
                    "UnityEngine.Events",
                    "UnityEngine.EventSystems",
                };
            return from type in getTypesByNamespaces(namespaces)
                   where _WillExportClass2TS(type)
                   select type;
        }
    }

    /// <summary>
    /// 第三方插件的代码绑定与导出（到ts）
    /// </summary>
    [Puerts.Binding]
    public static IEnumerable<Type> ThirdPartsBindings
    {
       get
       {
           string[] namespaces = {
                //    "DG.Tweening",
               };
           return from type in getTypesByNamespaces(namespaces)
                  where _WillExportClass2TS(type)
                  select type;
       }
    }

    /// <summary>
    /// 游戏自己的代码绑定与导出（到ts）
    /// </summary>
    [Puerts.Binding]
    public static IEnumerable<Type> GameBindings
    {
       get
       {
           return new List<Type>()
               {

               };
       }
    }

    [Puerts.BlittableCopy]
    public IEnumerable<Type> Blittables
    {
        get
        {
            return new List<Type>()
                {
                    //优化结构体的gc，但需要开启unsafe编译
                    typeof(UnityEngine.Vector2),
                    typeof(UnityEngine.Vector3),
                    typeof(UnityEngine.Vector4),
                    typeof(UnityEngine.Quaternion),
                    typeof(UnityEngine.Matrix4x4),
                    typeof(UnityEngine.Rect),
                    typeof(UnityEngine.Ray),
                    typeof(UnityEngine.Color),
                };
        }
    }

    [Puerts.Filter]
    public static bool FilterMethods(System.Reflection.MemberInfo mb)
    {
        if (!_WillExportMember2TS(mb))
        {//默认过滤掉
            return true;
        }
        if (mb.DeclaringType == typeof(UnityEngine.MonoBehaviour) && mb.Name == "runInEditMode")
        {// 排除 MonoBehaviour.runInEditMode, 在 Editor 环境下可用发布后不存在
            return true;
        }

        if (mb.DeclaringType == typeof(UnityEngine.UI.Text) && mb.Name == "OnRebuildRequested")
        {// 排除 Text.OnRebuildRequested, 在 Editor 环境下可用发布后不存在
            return true;
        }

        if (mb.DeclaringType == typeof(UnityEngine.UI.Graphic) && mb.Name == "OnRebuildRequested")
        {// 排除 Graphic.OnRebuildRequested, 在 Editor 环境下可用发布后不存在
            return true;
        }

        //默认不过滤
        return false;
    }

    /// <summary>
    /// 遍历给定命名空间public的所有类型
    /// </summary>
    /// <param name="spaceNameList">命名空间名称列表</param>
    /// <returns>类型列表</returns>
    private static IEnumerable<Type> getTypesByNamespaces(ICollection<string> spaceNameList)
    {
        return from assembly in validAssemblies
               from type in assembly.GetTypes()
               where spaceNameList.Contains(type.Namespace) && (type != null && type.IsPublic)
               select type;
    }

    /// <summary>
    /// 当前有效的程序集
    /// </summary>
    private static IEnumerable<Assembly> validAssemblies
    {
        get
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (assembly.ManifestModule is System.Reflection.Emit.ModuleBuilder)
                {
                    continue;
                }
                yield return assembly;
            }
        }
    }

    /// <summary>
    /// 判断给定类型是否应该导出
    /// </summary>
    /// <param name="type"></param>
    private static bool _WillExportClass2TS(Type type)
    {
        if (IsExcluded(type))
        {//被排除的类型
            return false;
        }
        if (type.IsDefined(typeof(System.ObsoleteAttribute)))
        {//过时的类
            return false;
        }
        if (type.IsSubclassOf(typeof(System.Attribute)))
        {//是C#属性类
            return false;
        }
        if (!string.IsNullOrEmpty(type.Namespace) && (type.Namespace.EndsWith(".Editor") || type.Namespace.Contains(".Editor.")))
        {//editor里的类不导出
            return false;
        }
        if (!(type.IsPublic || type.IsNestedPublic))
        {//不是公有的
            return false;
        }
        return true;
    }

    /// <summary>
    /// 判断给定的成员是否可以导出
    /// </summary>
    /// <param name="member"></param>
    /// <returns></returns>
    private static bool _WillExportMember2TS(System.Reflection.MemberInfo member)
    {
        if (member.IsDefined(typeof(System.ObsoleteAttribute)))
        {//过时的函数
            return false;
        }
        return true;
    }

    static bool IsExcluded(Type type)
    {
        if (type == null)
            return false;

        string assemblyName = Path.GetFileName(type.Assembly.Location);
        if (excludeAssemblys.Contains(assemblyName))
            return true;

        string fullname = type.FullName != null ? type.FullName.Replace("+", ".") : "";
        if (excludeTypes.Contains(fullname))
            return true;
        return IsExcluded(type.BaseType);
    }

    //需要排除的程序集
    static List<string> excludeAssemblys = new List<string>{
        "UnityEditor.dll",
        "Assembly-CSharp-Editor.dll",
    };

    //需要排除的类型
    static List<string> excludeTypes = new List<string>
    {
        "UnityEngine.iPhone",
        "UnityEngine.iPhoneTouch",
        "UnityEngine.iPhoneKeyboard",
        "UnityEngine.iPhoneInput",
        "UnityEngine.iPhoneAccelerationEvent",
        "UnityEngine.iPhoneUtils",
        "UnityEngine.iPhoneSettings",
        "UnityEngine.AndroidInput",
        "UnityEngine.AndroidJavaProxy",
        "UnityEngine.BitStream",
        "UnityEngine.ADBannerView",
        "UnityEngine.ADInterstitialAd",
        "UnityEngine.RemoteNotification",
        "UnityEngine.LocalNotification",
        "UnityEngine.NotificationServices",
        "UnityEngine.MasterServer",
        "UnityEngine.Network",
        "UnityEngine.NetworkView",
        "UnityEngine.ParticleSystemRenderer",
        "UnityEngine.ParticleSystem.CollisionEvent",
        "UnityEngine.ProceduralPropertyDescription",
        "UnityEngine.ProceduralTexture",
        "UnityEngine.ProceduralMaterial",
        "UnityEngine.ProceduralSystemRenderer",
        "UnityEngine.TerrainData",
        "UnityEngine.HostData",
        "UnityEngine.RPC",
        "UnityEngine.AnimationInfo",
        "UnityEngine.UI.IMask",
        "UnityEngine.Caching",
        "UnityEngine.Handheld",
        "UnityEngine.MeshRenderer",
        "UnityEngine.UI.DefaultControls",
        "UnityEngine.AnimationClipPair", //Obsolete
        "UnityEngine.CacheIndex", //Obsolete
        "UnityEngine.SerializePrivateVariables", //Obsolete
        "UnityEngine.Networking.NetworkTransport", //Obsolete
        "UnityEngine.Networking.ChannelQOS", //Obsolete
        "UnityEngine.Networking.ConnectionConfig", //Obsolete
        "UnityEngine.Networking.HostTopology", //Obsolete
        "UnityEngine.Networking.GlobalConfig", //Obsolete
        "UnityEngine.Networking.ConnectionSimulatorConfig", //Obsolete
        "UnityEngine.Networking.DownloadHandlerMovieTexture", //Obsolete
        "AssetModificationProcessor", //Obsolete
        "AddressablesPlayerBuildProcessor", //Obsolete
        "UnityEngine.WWW", //Obsolete
        "UnityEngine.EventSystems.TouchInputModule", //Obsolete
        "UnityEngine.MovieTexture", //Obsolete[ERROR]
        "UnityEngine.NetworkPlayer", //Obsolete[ERROR]
        "UnityEngine.NetworkViewID", //Obsolete[ERROR]
        "UnityEngine.NetworkMessageInfo", //Obsolete[ERROR]
        "UnityEngine.UI.BaseVertexEffect", //Obsolete[ERROR]
        "UnityEngine.UI.IVertexModifier", //Obsolete[ERROR]
        //Windows Obsolete[ERROR]
        "UnityEngine.EventProvider",
        "UnityEngine.UI.GraphicRebuildTracker",
        "UnityEngine.GUI.GroupScope",
        "UnityEngine.GUI.ScrollViewScope",
        "UnityEngine.GUI.ClipScope",
        "UnityEngine.GUILayout.HorizontalScope",
        "UnityEngine.GUILayout.VerticalScope",
        "UnityEngine.GUILayout.AreaScope",
        "UnityEngine.GUILayout.ScrollViewScope",
        "UnityEngine.GUIElement",
        "UnityEngine.GUILayer",
        "UnityEngine.GUIText",
        "UnityEngine.GUITexture",
        "UnityEngine.ClusterInput",
        "UnityEngine.ClusterNetwork",
        //System
        "System.Tuple",
        "System.Double",
        "System.Single",
        "System.ArgIterator",
        "System.SpanExtensions",
        "System.TypedReference",
        "System.StringBuilderExt",
        "System.IO.Stream",
        "System.Net.HttpListenerTimeoutManager",
        "System.Net.Sockets.SocketAsyncEventArgs",
        "TMPro.TMPro_ExtensionMethods", // FindInstanceID
    };
}